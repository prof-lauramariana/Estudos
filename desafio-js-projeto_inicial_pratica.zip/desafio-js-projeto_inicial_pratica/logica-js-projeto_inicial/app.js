console.log("Boas Vindas!")
let nome = "Laura";
console.log(`Olá, ${nome}!`);
alert(`Olá, ${nome}!`);
let pergunta = prompt(`${nome}, qual a linguangem de programação que você mais gosta?`);
console.log(`A linguagem de programação é: ${pergunta}`);

//Soma de valores (Para realizar outras operações basta trocar o sinal)
let valor1 = 10;
let valor2 = 2;
let resultado = valor1 + valor2;
console.log(`A soma de ${valor1} e ${valor2} é igual a ${resultado}.`);

//verificar maior idade
let idade = prompt("Qual sua idade?");
if(idade >= 18){
   console.log("Você é maior de idade");
}else{
   console.log("Você é menor de idade");
}

//Verificar se nuemero é negativo, positico ou zero
let numero = prompt("Digite um número");
if(numero < 0){
    console.log("Número negativo");
}else if(numero > 0){
    console.log("Número positivo");
}else {
    console.log("Número é igual a Zero");
}

//Criando um loop de 1 à 10
let contador = 1;
while(contador <= 10){
console.log(contador);
contador++;
}

//verifica se a nota é maior ou igual a 7
let nota = 6;
if(nota >= 7){
    console.log("Aprovado");
}else{
    console.log("Reprovado");
}

// exibir um número aleatório no console
let numeroAleatorio = Math.random();
console.log(numeroAleatorio);

// exibir um número inteiro entre 1 e 10 no console
let numeroInteiro = parseInt(Math.random() * 10) + 1;
console.log(numeroInteiro);

// exibir um número inteiro entre 1 e 10 no console
let numeroInteiro1 = parseInt(Math.random() * 1000) + 1;
console.log(numeroInteiro1);